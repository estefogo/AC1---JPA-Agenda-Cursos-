package com.ac1p2.ac1p2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ac1p2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
